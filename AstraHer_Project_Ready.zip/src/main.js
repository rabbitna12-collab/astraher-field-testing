import "./style.css";

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const DB_NAME="astraher-db", STORE="tests";
let stream=null, capturedBlob=null, capturedUrl=null, lastAnalysis=null;

const state={
  operator: localStorage.getItem("astraher_operator") || "OP-0457",
  tests:[]
};

function openDB(){
  return new Promise((resolve,reject)=>{
    const r=indexedDB.open(DB_NAME,1);
    r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE,{keyPath:"id"})};
    r.onsuccess=()=>resolve(r.result); r.onerror=()=>reject(r.error);
  });
}
async function dbAll(){
  const db=await openDB(); return new Promise((res,rej)=>{const q=db.transaction(STORE).objectStore(STORE).getAll();q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});
}
async function dbPut(x){
  const db=await openDB(); return new Promise((res,rej)=>{const q=db.transaction(STORE,"readwrite").objectStore(STORE).put(x);q.onsuccess=()=>res();q.onerror=()=>rej(q.error)});
}
async function sha256(blob){
  const buf=await blob.arrayBuffer(), hash=await crypto.subtle.digest("SHA-256",buf);
  return [...new Uint8Array(hash)].map(b=>b.toString(16).padStart(2,"0")).join("");
}
function toast(msg){const t=$("#toast");t.textContent=msg;t.style.display="block";setTimeout(()=>t.style.display="none",2300)}
function setView(id){
  $$(".view").forEach(x=>x.classList.remove("active")); $("#"+id)?.classList.add("active");
  $$(".nav button").forEach(x=>x.classList.toggle("active",x.dataset.view===id));
  const titles={dashboard:"Dashboard",camera:"New Test",result:"Test Result",evidence:"Evidence Record",history:"Test History",sync:"Sync Data",settings:"Settings"};
  $("#pageTitle").textContent=titles[id]||"AstraHer";
  if(id!=="camera")stopCamera();
  if(id==="history")renderHistory();
}
function login(){
  state.operator=$("#operator").value.trim()||"OP-0457";
  localStorage.setItem("astraher_operator",state.operator);
  $("#login").classList.add("hidden"); $("#app").classList.remove("hidden");
  $("#operatorLabel").textContent=state.operator; $("#welcomeOperator").textContent=state.operator; $("#settingsOperator").textContent=state.operator;
  renderRecent(); renderHistory();
}
function startCamera(){
  if(!navigator.mediaDevices?.getUserMedia){toast("Camera API is unavailable in this browser.");return}
  stopCamera();
  navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"},width:{ideal:1280},height:{ideal:720}},audio:false})
    .then(s=>{stream=s;$("#video").srcObject=s;$("#cameraHint").textContent="Camera ready — align the kit and reference card";})
    .catch(e=>{console.error(e);toast("Camera permission was denied or unavailable.");$("#cameraHint").textContent="Allow camera access to use live capture.";});
}
function stopCamera(){if(stream){stream.getTracks().forEach(t=>t.stop());stream=null}}
function capture(){
  const video=$("#video"), canvas=$("#captureCanvas");
  if(!video.videoWidth){toast("Start the camera first.");return}
  canvas.width=video.videoWidth;canvas.height=video.videoHeight;
  canvas.getContext("2d").drawImage(video,0,0);
  canvas.toBlob(async blob=>{
    capturedBlob=blob; if(capturedUrl)URL.revokeObjectURL(capturedUrl); capturedUrl=URL.createObjectURL(blob);
    $("#preview").src=capturedUrl; $("#previewWrap").classList.remove("hidden"); $("#cameraPanel").classList.add("hidden"); $("#analysisPanel").classList.remove("hidden");
    lastAnalysis=analyzeImage(canvas);
    renderChecks(lastAnalysis);
    stopCamera();
  },"image/jpeg",0.92);
}
function analyzeImage(canvas){
  const ctx=canvas.getContext("2d",{willReadFrequently:true});
  const w=Math.min(canvas.width,500), h=Math.round(canvas.height*w/canvas.width);
  const off=document.createElement("canvas");off.width=w;off.height=h;const c=off.getContext("2d");c.drawImage(canvas,0,0,w,h);
  const d=c.getImageData(0,0,w,h).data;let sum=0,sum2=0,count=0,edge=0;
  for(let y=1;y<h-1;y+=2)for(let x=1;x<w-1;x+=2){
    const i=(y*w+x)*4, gray=.299*d[i]+.587*d[i+1]+.114*d[i+2];
    sum+=gray;sum2+=gray*gray;count++;
    const l=(y*w+x-1)*4,r=(y*w+x+1)*4,u=((y-1)*w+x)*4,dd=((y+1)*w+x)*4;
    edge+=Math.abs((.299*d[l]+.587*d[l+1]+.114*d[l+2])-(.299*d[r]+.587*d[r+1]+.114*d[r+2]));
    edge+=Math.abs((.299*d[u]+.587*d[u+1]+.114*d[u+2])-(.299*d[dd]+.587*d[dd+1]+.114*d[dd+2]));
  }
  const mean=sum/count, variance=Math.max(0,sum2/count-mean*mean), contrast=Math.sqrt(variance);
  const brightness=Math.round(mean), sharpness=Math.round(edge/count);
  return {brightness,contrast:Math.round(contrast),sharpness};
}
function renderChecks(a){
  const bright=a.brightness>=45&&a.brightness<=220, contrast=a.contrast>=20, sharp=a.sharpness>=8;
  $("#qualityChecks").innerHTML=[
    [bright,`Exposure: ${a.brightness}/255`],
    [contrast,`Contrast: ${a.contrast}`],
    [sharp,`Blur/sharpness estimate: ${a.sharpness}`],
    [true,"Framing: capture area received"]
  ].map(([ok,t])=>`<div class="check ${ok?"ok":"warn"}">${ok?"✓":"⚠"} ${t}</div>`).join("");
  $("#analyzeBtn").disabled=!(bright&&contrast);
}
async function analyze(){
  if(!capturedBlob)return;
  $("#analyzeBtn").disabled=true;$("#analyzeBtn").textContent="Analyzing…";
  const id="#T-"+new Date().getFullYear()+"-"+String(Date.now()).slice(-6);
  let location={status:"Not granted"};
  try{
    location=await new Promise(resolve=>navigator.geolocation.getCurrentPosition(
      p=>resolve({status:"Granted",latitude:+p.coords.latitude.toFixed(6),longitude:+p.coords.longitude.toFixed(6),accuracy:Math.round(p.coords.accuracy)}),
      ()=>resolve({status:"Permission unavailable"}),{enableHighAccuracy:true,timeout:5000}
    ));
  }catch{}
  const hash=await sha256(capturedBlob);
  const a=lastAnalysis||{};
  const result=classifyResult(a);
  const test={id,operator:state.operator,timestamp:new Date().toISOString(),result,confidence:result==="Inconclusive"?61:92,quality:a,location,hash,image:await blobToDataURL(capturedBlob),synced:false};
  await dbPut(test); state.tests=await dbAll(); lastAnalysis=test;
  $("#resultStatus").textContent=result; $("#resultScore").textContent=test.confidence+"%"; $("#resultHash").textContent=hash;
  $("#resultTime").textContent=new Date(test.timestamp).toLocaleString();
  $("#resultOperator").textContent=test.operator; $("#resultLocation").textContent=location.status==="Granted"?`${location.latitude}, ${location.longitude}`:"Not granted";
  $("#evidenceId").textContent=test.id; $("#evidenceHash").textContent=hash; $("#evidenceImage").src=test.image;
  const cls=result.toLowerCase(); $("#resultBox").className="result "+(cls==="positive"?"":"");
  setView("result");$("#analyzeBtn").textContent="Analyze";$("#analyzeBtn").disabled=false;renderRecent();renderHistory();
}
function classifyResult(a){
  // Demonstration heuristic only. It is not a validated drug-testing classifier.
  if(a.brightness<30||a.brightness>235||a.contrast<12)return "Inconclusive";
  return "Negative";
}
function blobToDataURL(blob){return new Promise(r=>{const fr=new FileReader();fr.onload=()=>r(fr.result);fr.readAsDataURL(blob)})}
function renderRecent(){
  const rows=state.tests.slice().sort((a,b)=>b.timestamp.localeCompare(a.timestamp)).slice(0,4);
  $("#recent").innerHTML=(rows.length?rows:[]).map(t=>`<div class="row"><span><b>${t.id}</b><br><span class="muted">${new Date(t.timestamp).toLocaleString()}</span></span><span class="badge ${t.result.toLowerCase()}">${t.result}</span></div>`).join("")||'<div class="muted">No tests yet. Start a new capture.</div>';
  $("#testCount").textContent=state.tests.length;
  $("#pendingCount").textContent=state.tests.filter(x=>!x.synced).length;
}
function renderHistory(){
  const q=($("#historySearch")?.value||"").toLowerCase();
  const rows=state.tests.slice().sort((a,b)=>b.timestamp.localeCompare(a.timestamp)).filter(t=>JSON.stringify(t).toLowerCase().includes(q));
  $("#historyRows").innerHTML=rows.map(t=>`<tr><td><b>${t.id}</b></td><td>${new Date(t.timestamp).toLocaleString()}</td><td><span class="badge ${t.result.toLowerCase()}">${t.result}</span></td><td>${t.confidence}%</td><td>${t.operator}</td></tr>`).join("")||'<tr><td colspan="5">No records found.</td></tr>';
}
function exportEvidence(){
  if(!lastAnalysis?.id){toast("No evidence selected.");return}
  const out={...lastAnalysis,image:"[embedded capture omitted from JSON export for compactness]"};
  const blob=new Blob([JSON.stringify(out,null,2)],{type:"application/json"}), url=URL.createObjectURL(blob);
  const a=document.createElement("a");a.href=url;a.download=lastAnalysis.id.replace("#","")+"_evidence.json";a.click();URL.revokeObjectURL(url);
}
async function sync(){
  const tests=await dbAll(); for(const t of tests){t.synced=true;await dbPut(t)} state.tests=await dbAll();renderRecent();renderHistory();toast("All local records marked as synced.");
}
function resetCapture(){capturedBlob=null;$("#previewWrap").classList.add("hidden");$("#cameraPanel").classList.remove("hidden");$("#analysisPanel").classList.add("hidden");startCamera()}

document.querySelector("#root").innerHTML=`
<div id="login" class="login">
  <div class="login-card">
    <div class="login-head"><div class="logo">A</div><h1>AstraHer</h1><p>Digital Companion for Field Drug Testing</p></div>
    <form id="operatorForm">
      <div class="field"><label>Operator ID</label><input id="operator" value="OP-0457" autocomplete="username"></div>
      <div class="field"><label>Password</label><input type="password" value="demo" autocomplete="current-password"></div>
      <button class="btn primary full">Sign in</button>
    </form>
    <p class="muted" style="text-align:center;margin-top:15px">Secure field workflow • Offline-first</p>
  </div>
</div>
<div id="app" class="app hidden">
<aside class="side">
 <div class="brand"><div class="logo">A</div><div><b>AstraHer</b><small>Field Testing Companion</small></div></div>
 <nav class="nav">
  <button data-view="dashboard">⌂ <span>Dashboard</span></button>
  <button data-view="camera">◉ <span>New Test</span></button>
  <button data-view="history">▤ <span>Test History</span></button>
  <button data-view="sync">↥ <span>Sync Data</span></button>
  <button data-view="settings">⚙ <span>Settings</span></button>
 </nav>
 <div class="side-foot">SIH 2026 • AstraHer<br>Problem Statement 26231</div>
</aside>
<main class="main">
<header class="top"><h1 id="pageTitle">Dashboard</h1><span class="online">● Online</span></header>
<div class="content">
<section id="dashboard" class="view active">
 <div class="card hero"><h2>Ready for your next test?</h2><p>Use the device camera to capture the test and reference colour card. The browser performs local image-quality checks and creates an integrity record.</p><button id="startTest" class="btn light">Start New Test →</button></div>
 <div class="grid3" style="margin-top:18px">
  <div class="card"><span class="muted">Tests recorded</span><div id="testCount" class="kpi">0</div></div>
  <div class="card"><span class="muted">Awaiting sync</span><div id="pendingCount" class="kpi">0</div></div>
  <div class="card"><span class="muted">Operator</span><div id="welcomeOperator" class="kpi" style="font-size:22px">—</div></div>
 </div>
 <div class="card" style="margin-top:18px"><div class="title-row"><h2>Recent tests</h2><button class="btn light" onclick="setView('history')">View history</button></div><div id="recent" class="list"></div></div>
</section>

<section id="camera" class="view">
 <div class="title-row"><h2>New Test</h2><span id="cameraHint" class="muted">Camera not started</span></div>
 <div id="cameraPanel" class="grid2">
  <div class="camera-box"><div class="video-stage"><video id="video" autoplay playsinline muted></video><div class="guide"></div></div><div class="camera-controls"><button class="btn light" onclick="stopCamera()">Stop</button><button id="captureBtn" class="shutter" title="Capture"></button><button class="btn light" onclick="startCamera()">↻</button></div></div>
  <div class="card"><h2 style="margin-top:0">Capture checklist</h2><div class="list"><div class="row">Reference colour card <b>✓</b></div><div class="row">Test area visible <b>✓</b></div><div class="row">Good lighting <b>✓</b></div><div class="row">Operator <b id="operatorLabel">OP-0457</b></div></div><p class="muted" style="margin-top:16px">Camera permission is required. Keep the test and reference card inside the green guide.</p></div>
 </div>
 <canvas id="captureCanvas" class="hidden"></canvas>
 <div id="analysisPanel" class="grid2 hidden">
  <div class="card"><h2>Captured image</h2><img id="preview" class="preview"><div id="previewWrap" class="hidden"></div></div>
  <div class="card"><h2>Image quality</h2><div id="qualityChecks" class="checks"></div><div style="display:flex;gap:8px;margin-top:14px"><button id="retakeBtn" class="btn light">Retake</button><button id="analyzeBtn" class="btn primary">Analyze</button></div><p class="muted" style="margin-top:14px">Quality checks are local browser estimates.</p></div>
 </div>
</section>

<section id="result" class="view">
 <div class="title-row"><h2>Test Result</h2><span class="muted">Review before operational use</span></div>
 <div class="grid2">
  <div><div id="resultBox" class="result"><div class="circle">✓</div><h2 id="resultStatus">Negative</h2><span class="muted">Prototype classification</span><div id="resultScore" class="score">92%</div><span class="muted">Confidence score</span></div><button id="homeBtn" class="btn primary full" style="margin-top:14px">Save & Return Home</button></div>
  <div class="card"><h2 style="margin-top:0">Evidence record</h2><div class="evidence"><div class="kv"><small>Timestamp</small><b id="resultTime">—</b></div><div class="kv"><small>Operator</small><b id="resultOperator">—</b></div><div class="kv"><small>Location</small><b id="resultLocation">—</b></div><div class="kv"><small>SHA-256</small><b id="resultHash">—</b></div></div><button class="btn light full" style="margin-top:14px" onclick="setView('evidence')">View Full Evidence →</button></div>
 </div>
</section>

<section id="evidence" class="view">
 <div class="title-row"><h2>Evidence Record</h2><button id="exportBtn" class="btn primary">Export JSON</button></div>
 <div class="card"><img id="evidenceImage" class="preview" style="max-height:420px;object-fit:contain"><div class="evidence"><div class="kv"><small>Test ID</small><b id="evidenceId">—</b></div><div class="kv"><small>Operator</small><b id="evidenceOperator">—</b></div><div class="kv"><small>SHA-256 image hash</small><b id="evidenceHash">—</b></div><div class="kv"><small>Integrity</small><b style="color:var(--green)">Hash generated locally</b></div></div><p class="muted">The hash is a cryptographic digest of the captured image. It does not by itself establish authenticity or forensic validity.</p></div>
</section>

<section id="history" class="view">
 <div class="title-row"><h2>Test History</h2><button id="newFromHistory" class="btn primary">+ New Test</button></div>
 <div class="card"><input id="historySearch" class="search" placeholder="Search by ID, operator, date, result"><table class="table"><thead><tr><th>Test ID</th><th>Date / Time</th><th>Result</th><th>Confidence</th><th>Operator</th></tr></thead><tbody id="historyRows"></tbody></table></div>
</section>

<section id="sync" class="view">
 <div class="grid2"><div class="card"><h2>Sync Data</h2><p class="muted">This demo stores records locally. Press sync to mark local records ready for backend upload.</p><button id="syncBtn" class="btn primary">Sync local records</button></div><div class="card"><h2>Offline-first</h2><div class="list"><div class="row">Local storage <span class="badge negative">Enabled</span></div><div class="row">Service worker <span class="badge negative">Enabled</span></div><div class="row">Automatic backend sync <span class="badge inconclusive">Not connected</span></div></div></div></div>
</section>

<section id="settings" class="view"><div class="card"><h2>Settings</h2><div class="list"><div class="row"><span><b>Operator account</b><br><span class="muted">Current operator: <span id="settingsOperator">OP-0457</span></span></span>›</div><div class="row"><span><b>Camera</b><br><span class="muted">Rear camera preferred</span></span>›</div><div class="row"><span><b>Security</b><br><span class="muted">SHA-256 evidence hash</span></span>›</div><div class="row"><span><b>Storage</b><br><span class="muted">IndexedDB local records</span></span>›</div></div></div></section>
</div></main></div><div id="toast" class="toast"></div>`;
document.addEventListener("DOMContentLoaded",async()=>{
  state.tests=await dbAll();
  $("#operator").value=state.operator;
  $("#operatorForm").addEventListener("submit",e=>{e.preventDefault();login()});
  $$(".nav button").forEach(b=>b.addEventListener("click",()=>setView(b.dataset.view)));
  $("#startTest").onclick=()=>{setView("camera");startCamera()};
  $("#captureBtn").onclick=capture; $("#analyzeBtn").onclick=analyze; $("#retakeBtn").onclick=resetCapture;
  $("#exportBtn").onclick=exportEvidence; $("#syncBtn").onclick=sync; $("#historySearch").oninput=renderHistory;
  $("#homeBtn").onclick=()=>setView("dashboard");
  $("#newFromHistory").onclick=()=>{setView("camera");startCamera()};
  renderRecent();renderHistory();
  if("serviceWorker" in navigator)navigator.serviceWorker.register("/sw.js").catch(()=>{});
});
