# AstraHer — Project-Ready Web App

A working browser prototype based on the AstraHer SIH 2026 concept.

## Features
- Operator login
- Real device camera using `getUserMedia`
- Live framing guide
- Capture a test image
- Client-side image-quality checks:
  - brightness/exposure
  - contrast
  - blur estimate
  - framing coverage
- Reference-colour sampling from the captured image
- Result workflow with Positive / Negative / Inconclusive states
- Confidence score (prototype heuristic, not a validated diagnostic/forensic model)
- Browser geolocation when permission is granted
- SHA-256 hash of the captured image for an integrity record
- Local/offline test storage using IndexedDB
- Test history and search
- JSON evidence export
- Offline service worker shell

## Run locally

Requires Node.js 18+.

```bash
npm install
npm run dev
```

Open the local URL shown by Vite, normally `http://localhost:5173`.

Camera and geolocation permissions work on localhost. For deployment, use HTTPS.

## Build

```bash
npm run build
npm run preview
```

## Important
This is a field-workflow prototype. The classification logic is deliberately a demo heuristic and must NOT be treated as a validated drug identification method, laboratory result, or forensic conclusion. Replace `classifyResult()` in `src/main.js` with a validated model/calibration procedure before operational use.
